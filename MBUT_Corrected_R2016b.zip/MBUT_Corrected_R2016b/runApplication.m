function runApplication()

    applicationRoot = fileparts(mfilename('fullpath'));

    addpath(applicationRoot);
    addpath(fullfile(applicationRoot, 'views'));
    addpath(fullfile(applicationRoot, 'backend'));

    MainApplication();

end
