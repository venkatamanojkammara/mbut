MBUT - Corrected MATLAB R2016b Package
=======================================

START
-----
Open MATLAB in this folder and run:

    runApplication

UI PRESERVATION
---------------
MainApplication.m and the four current view files were copied byte-for-byte
from the latest supplied UI source files.

No Position, color, font, text, axes, card, line, curvature, spacing or layout
property was rewritten during packaging.

STRUCTURE
---------
MainApplication.m
runApplication.m

views/
    view_ModelSetup.m
    view_TestCaseManagement.m
    view_BatchRun.m
    view_PlotAndReport.m

backend/
    Existing backend implementation files

report_templates/
    Report template location

IMPORTANT
---------
The current view callbacks remain in the current view files so their existing
working behavior and UI interaction are preserved. The existing backend
functions are available through the backend folder.

This corrected package intentionally avoids the previous controller/service
rewrite because that rewrite changed the UI baseline and introduced interface
assumptions.
