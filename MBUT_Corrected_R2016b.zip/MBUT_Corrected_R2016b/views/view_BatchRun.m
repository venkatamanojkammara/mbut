function handles = view_BatchRun(parentPanel)

    C.Background      = [0.945 0.953 0.965];
    C.Card            = [1.000 1.000 1.000];
    C.CardBorder      = [0.855 0.875 0.905];
    C.TextPrimary     = [0.105 0.125 0.160];
    C.TextSecondary   = [0.420 0.455 0.510];
    C.TextMuted       = [0.570 0.600 0.650];
    C.InputBackground = [0.975 0.980 0.988];
    C.Primary         = [0.125 0.350 0.620];
    C.DarkButton      = [0.120 0.145 0.185];
    C.SecondaryButton = [0.900 0.920 0.945];
    C.Divider         = [0.900 0.915 0.935];
    C.White           = [1 1 1];

    handles.MainPanel = uipanel( ...
        'Parent', parentPanel, ...
        'Units', 'normalized', ...
        'Position', [0 0 1 1], ...
        'BackgroundColor', C.Background, ...
        'BorderType', 'none');

    fig = ancestor(handles.MainPanel, 'figure');

    handles.BatchAxes = axes( ...
        'Parent', handles.MainPanel, ...
        'Units', 'normalized', ...
        'Position', [0.045 0.065 0.91 0.885], ...
        'XLim', [0 1], ...
        'YLim', [0 1], ...
        'Visible', 'off', ...
        'Color', 'none');

    rectangle( ...
        'Parent', handles.BatchAxes, ...
        'Position', [0.005 0.005 0.99 0.99], ...
        'Curvature', [0.01 0.01], ...
        'FaceColor', C.Card, ...
        'EdgeColor', C.CardBorder, ...
        'LineWidth', 1);

    text(0.045, 0.925, 'Batch Run', ...
        'Parent', handles.BatchAxes, ...
        'FontName', 'Segoe UI', ...
        'FontSize', 14, ...
        'FontWeight', 'bold', ...
        'Color', C.TextPrimary, ...
        'Interpreter', 'none');

    text(0.045, 0.875, ...
        'Manage multiple XML test case files and execute batch workflows.', ...
        'Parent', handles.BatchAxes, ...
        'FontName', 'Segoe UI', ...
        'FontSize', 9.5, ...
        'Color', C.TextSecondary, ...
        'Interpreter', 'none');

    line([0.045 0.955], [0.830 0.830], ...
        'Parent', handles.BatchAxes, ...
        'Color', C.Divider, ...
        'LineWidth', 1);

    text(0.045, 0.775, 'Test Case Files', ...
        'Parent', handles.BatchAxes, ...
        'FontName', 'Segoe UI', ...
        'FontSize', 11, ...
        'FontWeight', 'bold', ...
        'Color', C.TextPrimary, ...
        'Interpreter', 'none');

    handles.FileCountText = text(0.955, 0.775, '0 files', ...
        'Parent', handles.BatchAxes, ...
        'HorizontalAlignment', 'right', ...
        'FontName', 'Segoe UI', ...
        'FontSize', 9, ...
        'Color', C.TextMuted, ...
        'Interpreter', 'none');

    handles.ExcelPathListBox = uicontrol( ...
        'Parent', handles.MainPanel, ...
        'Style', 'listbox', ...
        'Units', 'normalized', ...
        'Position', [0.085 0.295 0.830 0.405], ...
        'String', {}, ...
        'Min', 0, ...
        'Max', 100, ...
        'Value', [], ...
        'FontName', 'Segoe UI', ...
        'FontSize', 10, ...
        'ForegroundColor', C.TextPrimary, ...
        'BackgroundColor', C.InputBackground, ...
        'Callback', @onExcelPathSelected);

    handles.AddXMLButton = createRoundedButton( ...
        handles.BatchAxes, [0.045 0.125 0.180 0.075], ...
        'Add XML', C.Primary, C.White, @addExcelCallback);

    handles.DeleteButton = createRoundedButton( ...
        handles.BatchAxes, [0.245 0.125 0.150 0.075], ...
        'Delete', C.SecondaryButton, C.TextPrimary, @deleteSelectedExcel);

    line([0.425 0.425], [0.130 0.205], ...
        'Parent', handles.BatchAxes, ...
        'Color', C.Divider, ...
        'LineWidth', 1);

    handles.ExecuteSimulationButton = createRoundedButton( ...
        handles.BatchAxes, [0.465 0.125 0.180 0.075], ...
        'Execute Simulation', C.Primary, C.White, @onExecuteSimulation);

    handles.BatchRunButton = createRoundedButton( ...
        handles.BatchAxes, [0.665 0.125 0.130 0.075], ...
        'Batch Run', C.DarkButton, C.White, @onAutomaticBatchRun);

    handles.TestCasesRunButton = createRoundedButton( ...
        handles.BatchAxes, [0.815 0.125 0.140 0.075], ...
        'Test Cases Run', C.DarkButton, C.White, @onRunTestCases);

    setappdata(fig, 'excelPathListBox', handles.ExcelPathListBox);
    setappdata(fig, 'deleteExcelBtn', handles.DeleteButton);

    if ~isappdata(fig, 'excelPathList')
        setappdata(fig, 'excelPathList', {});
    end

    setappdata(fig, 'selectedExcelIdx', []);
    updateFileList();
    setStatus('Ready', 'ready');


    function addExcelCallback(~, ~)

        [fileName, pathName] = uigetfile( ...
            {'*.xml', 'XML Test Case Files (*.xml)'}, ...
            'Select XML Test Case File', ...
            'MultiSelect', 'on');

        if isequal(fileName, 0)
            return;
        end

        paths = getappdata(fig, 'excelPathList');

        if isempty(paths)
            paths = {};
        end

        if ischar(fileName)
            fileName = {fileName};
        end

        for i = 1:numel(fileName)

            xmlPath = fullfile(pathName, fileName{i});

            if ~any(strcmp(paths, xmlPath))
                paths{end + 1, 1} = xmlPath; %#ok<AGROW>
            end

            logMessage(xmlPath, ...
                'Selected XML for Batch Run %s', xmlPath);

        end

        setappdata(fig, 'excelPathList', paths);
        setappdata(fig, 'selectedExcelIdx', []);

        updateFileList();
        setStatus('Test case files added.', 'success');

    end


    function onExcelPathSelected(source, ~)

        paths = getappdata(fig, 'excelPathList');

        if isempty(paths)
            setappdata(fig, 'selectedExcelIdx', []);
            return;
        end

        idx = get(source, 'Value');
        idx = idx(idx >= 1 & idx <= numel(paths));

        setappdata(fig, 'selectedExcelIdx', idx);

    end


    function deleteSelectedExcel(~, ~)

        paths = getappdata(fig, 'excelPathList');
        idx = getappdata(fig, 'selectedExcelIdx');

        if isempty(paths) || isempty(idx)
            setStatus('Select one or more files to delete.', 'warning');
            return;
        end

        idx = unique(idx);
        idx = idx(idx >= 1 & idx <= numel(paths));

        if isempty(idx)
            return;
        end

        deletingPaths = paths(idx);

        for i = 1:numel(deletingPaths)
            logMessage(deletingPaths{i}, ...
                'Deleting XML from Batch Run %s', ...
                deletingPaths{i});
        end

        paths(idx) = [];

        setappdata(fig, 'excelPathList', paths);
        setappdata(fig, 'selectedExcelIdx', []);

        updateFileList();
        setStatus('Selected files removed.', 'success');

    end


    function onExecuteSimulation(~, ~)

        excelPaths = getappdata(fig, 'excelPathList');

        if isempty(excelPaths)

            errordlg( ...
                'No XML files added. Please add at least one XML file.', ...
                'Execute Simulation');

            setStatus('No test case files available.', 'warning');
            return;

        end

        setStatus('Executing batch simulation...', 'working');
        drawnow;

        try

            batch_run(excelPaths);

            setStatus('Batch simulation completed.', 'success');

        catch ME

            setStatus('Batch simulation failed.', 'error');

            errordlg( ...
                ME.message, ...
                'Batch Simulation');

        end

    end


    function onAutomaticBatchRun(~, ~)

        rootDir = uigetdir( ...
            pwd, ...
            'Select Root Folder for Batch Run');

        if isequal(rootDir, 0)
            return;
        end

        choice = questdlg( ...
            sprintf([ ...
                'Selected folder:\n\n%s\n\n' ...
                'Do you want to continue with Batch Run?'], ...
                rootDir), ...
            'Confirm Batch Run', ...
            'Continue with Batch Run', ...
            'Generate only Reports', ...
            'Cancel', ...
            'Continue with Batch Run');

        if isempty(choice) || strcmp(choice, 'Cancel')

            setStatus('Batch run cancelled.', 'warning');
            return;

        end

        setStatus('Scanning Test_* folders...', 'working');
        drawnow;

        excelPaths = getAllExcelFilesRecursive(rootDir);

        if isempty(excelPaths)

            errordlg( ...
                ['No valid Test_* folders with matching ' ...
                 '*_TestCase.xml files found.'], ...
                'Batch Run Error');

            setStatus('No valid XML files found.', 'error');
            return;

        end

        setappdata(fig, 'excelPathList', excelPaths);
        setappdata(fig, 'selectedExcelIdx', []);

        updateFileList();

        if strcmp(choice, 'Generate only Reports')

            setStatus( ...
                'Generating consolidated batch report...', ...
                'working');

            generateHTMLReport(excelPaths);
            return;

        end

        setStatus( ...
            sprintf('Loaded %d XML files. Executing...', ...
            numel(excelPaths)), ...
            'working');

        drawnow;

        try

            batch_run(excelPaths);

            setStatus('Automatic batch run completed.', 'success');

        catch ME

            setStatus('Automatic batch run failed.', 'error');

            errordlg( ...
                ME.message, ...
                'Batch Run');

        end

    end


    function onRunTestCases(~, ~)

        folderPath = uigetdir( ...
            pwd, ...
            'Select Folder Containing XML Test Cases');

        if isequal(folderPath, 0)

            setStatus('Folder selection cancelled.', 'warning');
            return;

        end

        xmlFiles = dir(fullfile(folderPath, '*.xml'));

        if isempty(xmlFiles)

            setStatus('No XML files found.', 'warning');

            errordlg( ...
                'No XML files found in the selected folder.', ...
                'Test Cases Run');

            return;

        end

        fullPaths = cell(numel(xmlFiles), 1);

        for i = 1:numel(xmlFiles)
            fullPaths{i} = fullfile(folderPath, xmlFiles(i).name);
        end

        setappdata(fig, 'excelPathList', fullPaths);
        setappdata(fig, 'selectedExcelIdx', []);

        updateFileList();

        setStatus('Running XML test cases...', 'working');
        drawnow;

        try

            perform_full_testcases_batch_run(xmlFiles, fig);

            setStatus( ...
                sprintf('Executed %d test case files.', ...
                numel(fullPaths)), ...
                'success');

        catch ME

            setStatus('Error running test cases.', 'error');

            errordlg( ...
                ME.message, ...
                'Test Cases Run');

        end

    end


    function excelPaths = getAllExcelFilesRecursive(rootDir)

        excelPaths = {};

        allDirs = strsplit(genpath(rootDir), pathsep);
        allDirs = allDirs(~cellfun('isempty', allDirs));
        allDirs = sort(allDirs);

        for directoryIndex = 1:numel(allDirs)

            folderPath = allDirs{directoryIndex};
            [~, folderName] = fileparts(folderPath);

            if length(folderName) < 5 || ...
                    ~strcmp(folderName(1:5), 'Test_')
                continue;
            end

            xmlFiles = dir(fullfile( ...
                folderPath, ...
                '*_TestCase.xml'));

            for fileIndex = 1:numel(xmlFiles)

                fullPath = fullfile( ...
                    folderPath, ...
                    xmlFiles(fileIndex).name);

                if exist(fullPath, 'file') == 2
                    excelPaths{end + 1, 1} = fullPath; %#ok<AGROW>
                end

            end

        end

        if ~isempty(excelPaths)
            excelPaths = unique(excelPaths, 'stable');
        end

    end


    function generateHTMLReport(path)

        if ischar(path)
            excelPaths = {path};
        elseif iscell(path)
            excelPaths = path;
        else
            errordlg( ...
                'Invalid report input path.', ...
                'Report Error');
            return;
        end

        excelPaths = excelPaths(~cellfun('isempty', excelPaths));

        if isempty(excelPaths)

            errordlg( ...
                'No XML files are available for report generation.', ...
                'Report Error');

            setStatus('No files available for reporting.', 'warning');
            return;

        end

        templatesDir = fullfile( ...
            fileparts(mfilename('fullpath')), ...
            'ConsolidatedReportTemplates');

        setStatus('Generating HTML report...', 'working');
        drawnow;

        try

            indexHtmlPath = build_full_report( ...
                excelPaths, ...
                templatesDir);

            msgbox( ...
                'Report generated successfully.', ...
                'Success');

            try
                web(indexHtmlPath, '-browser');
            catch
                warning('Could not open HTML report automatically.');
            end

            setStatus('Report generated successfully.', 'success');

        catch ME

            setStatus('Report generation failed.', 'error');

            errordlg( ...
                ME.message, ...
                'Report Error');

        end

    end


    function updateFileList()

        paths = getappdata(fig, 'excelPathList');

        if isempty(paths)

            set(handles.ExcelPathListBox, ...
                'String', {}, ...
                'Value', []);

        else

            set(handles.ExcelPathListBox, ...
                'String', paths, ...
                'Value', []);

        end

        fileCount = numel(paths);

        if fileCount == 1
            countString = '1 file';
        else
            countString = sprintf('%d files', fileCount);
        end

        set(handles.FileCountText, 'String', countString);

    end


    function logMessage(referencePath, varargin)

        if isempty(referencePath)
            return;
        end

        try

            logFile = fullfile( ...
                fileparts(referencePath), ...
                'commandLog.txt');

            commandLog(logFile, varargin{:});

        catch
        end

    end


    function setStatus(statusMessage, statusType)

        if nargin < 2
            statusType = 'ready';
        end

        statusText = getappdata(fig, 'statusText');
        statusIndicator = getappdata(fig, 'statusIndicator');

        if ~isempty(statusText) && ishandle(statusText)
            set(statusText, 'String', ['  ' statusMessage]);
        end

        if ~isempty(statusIndicator) && ishandle(statusIndicator)

            switch lower(statusType)
                case 'working'
                    indicatorColor = [0.125 0.350 0.620];
                case 'success'
                    indicatorColor = [0.145 0.520 0.330];
                case 'warning'
                    indicatorColor = [0.850 0.560 0.120];
                case 'error'
                    indicatorColor = [0.720 0.220 0.220];
                otherwise
                    indicatorColor = [0.145 0.520 0.330];
            end

            set(statusIndicator, ...
                'ForegroundColor', indicatorColor);

        end

        try

            state = evalin('base', 'GUI_STATE');

            if ~isstruct(state)
                state = struct();
            end

        catch

            state = struct();

        end

        state.STATUS = statusMessage;
        assignin('base', 'GUI_STATE', state);

        drawnow;

    end


    function buttonHandles = createRoundedButton( ...
            parentAxes, position, buttonText, ...
            backgroundColor, textColor, callbackFunction)

        buttonHandles = struct();

        buttonHandles.Background = rectangle( ...
            'Parent', parentAxes, ...
            'Position', position, ...
            'Curvature', [0.16 0.35], ...
            'FaceColor', backgroundColor, ...
            'EdgeColor', backgroundColor, ...
            'LineWidth', 1, ...
            'ButtonDownFcn', callbackFunction);

        buttonHandles.Text = text( ...
            position(1) + position(3) / 2, ...
            position(2) + position(4) / 2, ...
            buttonText, ...
            'Parent', parentAxes, ...
            'HorizontalAlignment', 'center', ...
            'VerticalAlignment', 'middle', ...
            'FontName', 'Segoe UI', ...
            'FontSize', 9.5, ...
            'FontWeight', 'bold', ...
            'Color', textColor, ...
            'Interpreter', 'none', ...
            'HitTest', 'on', ...
            'ButtonDownFcn', callbackFunction);

    end

end
